<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pdffile extends Model
{
    //
}
