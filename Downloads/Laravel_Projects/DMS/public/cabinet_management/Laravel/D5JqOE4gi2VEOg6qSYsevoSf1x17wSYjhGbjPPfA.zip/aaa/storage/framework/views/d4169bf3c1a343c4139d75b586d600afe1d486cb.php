<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  
</head>
<body>

<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Sr. No.</th>
      <th scope="col">Company Name</th>
      <th scope="col">Company Location</th>
      <th scope="col">Action</th>
      <th><a href="<?php echo e(url('company-create')); ?>"><button class="btn btn-primary">Add+</button></a></th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($loop->index+1); ?></td>
      <td><?php echo e($comp->name); ?></td>
      <td><?php echo e($comp->location); ?></td>
      <td><a href="<?php echo e(url('company-edit')); ?>/<?php echo e($comp->id); ?>"><button class="btn btn-primary btn-sm">
         Edit<button></a>
         <a  href="<?php echo e(url('company-delete')); ?>/<?php echo e($comp->id); ?>"><button class="btn btn-danger btn-sm">
         delete<button></a>
      </td>
    </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</body>
</html><?php /**PATH C:\xampp\htdocs\DMS\resources\views/company/company-index.blade.php ENDPATH**/ ?>