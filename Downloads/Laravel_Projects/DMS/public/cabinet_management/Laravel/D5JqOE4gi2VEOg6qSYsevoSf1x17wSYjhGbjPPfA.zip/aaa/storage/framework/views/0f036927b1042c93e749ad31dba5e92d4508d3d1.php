<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<form method="" class="form-group">
<div class="row" style="border:1px solid black;">
<div class="col-md-8">
<h3>All Input Type In HTML</h3>
<input type="button" class="form-control"><br>
<input type="checkbox" class="form-control"><br>
<input type="color" class="form-control"><br>
<input type="date" class="form-control"><br>
<input type="datetime-local" class="form-control"><br>
<input type="email" class="form-control"><br>
<input type="file" class="form-control"><br>
<input type="hidden" class="form-control"><br>
<input type="image" class="form-control"><br>
<input type="month" class="form-control"><br>
<input type="number" class="form-control"><br>
<input type="password" class="form-control"><br>
<input type="radio" class="form-control"><br>
<input type="range" class="form-control"><br>
<input type="reset" class="form-control"><br>
<input type="search" class="form-control"><br>
<input type="submit" class="form-control"><br>
<input type="tel" class="form-control"><br>
<input type="text" class="form-control"><br>
<input type="time" class="form-control"><br>
<input type="url" class="form-control"><br>
<input type="week" class="form-control"><br>
</div>
</div>
</form>
</body>
</html>


<?php $__env->startSection('content'); ?>
<!DOCTYPE html>

<head>
     <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  

    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

</head>
<body>
 
  <div class="card uper">
<div class="card-header">
  <h4 style="text-align:center;">Details Of Tables</h4>
  <b><a class="btn btn-info" href="<?php echo e(url('/table-index')); ?>"><span class="glyphicon glyphicon-circle-arrow-left"></span> Back</a></b>
  <b><a class="btn btn-info active" href="<?php echo e(url('show')); ?>/<?php echo e($table_name); ?>"><span class="glyphicon glyphicon-plus-sign"></span> Brower</a></b>
  <b><a class="btn btn-info" href="<?php echo e(url('/structure')); ?>/<?php echo e($table_name); ?>"><span class="glyphicon glyphicon-plus-sign"></span> Structure</a></b> 
  <b><a class="btn btn-info" href="<?php echo e(url('table-record-insert')); ?>/<?php echo e($table_name); ?>"><span class="glyphicon glyphicon-plus-sign"></span> Insert</a></b>
   </div>
 
  <div class="card-body">
    <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br/>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(url('/table-record-store')); ?>/<?php echo e($table_name); ?>" data-type="">
    <?php echo csrf_field(); ?>
     <table class="table table-striped">
    <thead style="background-color:skyblue;">
     <tr>
     <th>Column</th>
     <th></th>
     <th>Type</th>
     <th></th>
     <th>Null</th>
     <th>Value</th>
     <!-- <th>Key</th>
     <th></th>
     <th>Default</th>
     <th></th>
     <th>Extra</th> -->
   </tr>
   </thead>
    <tbody>
  
 <?php $__currentLoopData = $datatype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <tr>
 <td><?php echo e($value->Field); ?><td>
 <td><?php echo e($value->Type); ?><td>
 <?php if($value->Type == 'timestamp'): ?>
 <td><input type="checkbox" value="2" name="<?php echo e($value->Field); ?>"></td>
 <?php else: ?> 
 <td></td>
 <?php endif; ?>

 <td><input type="<?php echo e($value->Type); ?>" class="form-control" name="<?php echo e($value->Field); ?>" class="form-control"><td>
 </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
 </table>
 <input type="submit" class="btn btn-primary" style="float:right;" value="Go" class="form-control">
 </form>
</div>
</div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DMS\resources\views/forms/form-create.blade.php ENDPATH**/ ?>