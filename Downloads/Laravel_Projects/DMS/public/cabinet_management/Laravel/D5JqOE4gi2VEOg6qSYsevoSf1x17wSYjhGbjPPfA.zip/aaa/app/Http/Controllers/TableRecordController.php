<?php

namespace App\Http\Controllers;

use App\TableRecord;
use Illuminate\Http\Request;
use DB;

class TableRecordController extends Controller
{

    public function createDynamicForm($table_name)
    {
        $columns = DB::getSchemaBuilder()->getColumnListing($table_name);
        $datatype = DB::select('describe '.$table_name);
        $table_info = DB::table('table_infos')->where('table_name', $table_name)->get();
        $table_info = json_decode($table_info, true);
        // dd($table_info);
        return view('tables.table-insert-form', ['table_info'=>$table_info,'columns'=>$columns, 'datatype'=>$datatype, 'table_name'=>$table_name]);
    }

    public function storeDynamicForm($table_name, request $request)
    {
        $columns = DB::getSchemaBuilder()->getColumnListing($table_name);
        $field_data = DB::table($table_name)->get();
        $validateData = $request->validate([
            
        ]);

        $input = $request->input();
        unset($input['_token']);
        unset($input['created_at']);
        unset($input['updated_at']);

        DB::table($table_name)->insert($input);
  
     return redirect()->back()->with('success', 'Data inserted Successfully!'); 
    }

    public function editRecord($table_name, $id)
    {
        $columns = DB::getSchemaBuilder()->getColumnListing($table_name);
        $datatype = DB::select('describe '.$table_name);
        $data_edit = DB::table($table_name)->where('id', $id)->get();
   
       return view('tables.table-edit-form', ['columns'=>$columns, 'datatype'=>$datatype, 'table_name'=>$table_name, 'data_edit'=>$data_edit]);
    }

    public function deleteRecord($table_name, $id){
        
        $delete = DB::table($table_name)->where('id', $id)->delete();

        return redirect()->back()->with('Danger', 'Data Deleted Successfully!'); 
        
     }
    public function tableStructure($table_name){
       
        $columns = DB::getSchemaBuilder()->getColumnListing($table_name);
        $datatype = DB::select('describe '.$table_name);
       
        return view('tables.table-structure', ['columns'=>$columns, 'datatype'=>$datatype, 'table_name'=>$table_name]);
    }
}
