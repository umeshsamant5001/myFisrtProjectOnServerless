<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>

    <!-- <title>Dynamically Add Table In Database</title> -->

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  

    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

</head>

<!-- <style>
  .uper {
    margin-top: 40px;
  }
</style> -->

<body>

<div class="container">

    <div class="form-group">

         <form name="add_name" method="POST" action="<?php echo e(url('/table-store')); ?>">
          <?php echo csrf_field(); ?>
            <div class="table-responsive">  
          
                <table class="table table-bordered" id="dynamic_field">  
                 <!-- <tr>   
                      <th>Table Name</th>  
                      <td colspan="3"><input type="text" name="table_name" class="form-control" required=""></td>
                 </tr> -->
                 <tr>   
                 <?php $__currentLoopData = $columns_name[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th style="background-color:skyblue;"><?php echo e($key); ?></th>  
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </tr>
                  
                <tr> 
                  <?php $__currentLoopData = $columns_name[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <td><input type="text" value="<?php echo e($value); ?>" name="name[]"class="form-control name_list"/></td>  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </tr>
                </table>  
                <input type="submit" name="submit" id="submit" class="btn btn-info" value="Update"/>  
            </div>
        </form>  
    </div> 
</div>
<body>
<html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DMS\resources\views/tables/column-edit.blade.php ENDPATH**/ ?>