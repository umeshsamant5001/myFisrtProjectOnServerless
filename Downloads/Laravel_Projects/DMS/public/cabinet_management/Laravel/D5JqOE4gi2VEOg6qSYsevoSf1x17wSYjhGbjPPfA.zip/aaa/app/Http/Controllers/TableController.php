<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\company;
use App\table_info;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;

class TableController extends Controller
{
    public function index(){
        $table_na = DB::select('SHOW TABLES');
        $data_type = DB::table('data_type_table')->get();

        return view('tables.table-index', ['table_na'=> $table_na, 'data_type'=>$data_type]);
    }

    public function getDatatype($id)
{
    $states = DB::table("states")
                ->where("country_id",$id)
                ->pluck("state_name","id");
    return response()->json($states);
}

    public function showTable(){
        return view('tables.table-create');
    }

    public function createTable($table_name, $fields = [])
    {
        // check if table is not already exists
        if (!Schema::hasTable($table_name)) {
            Schema::create($table_name, function (Blueprint $table) use ($fields, $table_name) {
                $table->increments('id');
                if (count($fields) > 0) {
                    foreach ($fields as $field) {
                       $table->{$field['type']}($field['name']);
                    }
                }
                $table->timestamps();
            });

            return redirect('/table-index')->with('success', 'Given table has been successfully created!');   
        }

        return redirect('/table-index')->with('success', 'Given table is already existis.');
    }

    public function operate(request $request)
    {
        // set dynamic table name according to your requirements
       
        $validatedData = $request->validate([

            'table_name' => 'required|max:255',
            'name' => 'required',
        ]);
    
        $table_name = $request->table_name;

        $name = $request->name;
        $type = $request->type;


    // $fields = ['name' => $name, 'type' => $type];

     for($i = 0; $i < count($request->name); $i++){
  
        $fields[$i]['name']=$request->name[$i];
        $fields[$i]['type']=$request->type[$i];
        }

        //Insert data table_info
    
        $input = $request->input();
        // unset($input['_token']);
        // dd($input);
        for($i=0; $i<count($input['name']); $i++){

       $dd = DB::table('table_infos')->insert([
            "table_name" => $input['table_name'],
            "column_name" => $input['name'][$i],
            "control_type" => $input['control_type'],
            "display_name" => $input['display_name'][$i],
        ]);    
    }    
       // end here Insert data table_info    
        return $this->createTable($table_name, $fields);
         
    }

    public function down($table_name)
    {   
        DB::table('table_infos')->where('table_name', $table_name)->delete();
        Schema::dropIfExists($table_name);  

        return redirect('/table-index')->with('danger', 'Given table has been Deleted!');   
    }
 
    public function renameTable(request $request, table_name $table_name)
    {
        $newTableName = $request->newTableName;

        Schema::rename($table_name, $newTableName);    
    }

    public function renameColumn($table_name){

        $columns_name = DB::select('describe '.$table_name);
        $col = json_encode($columns_name);
        $someArray = json_decode($col, true);
    
        Schema::table($table_name, function($table)
        {  
          
          $table->renameColumn('sonali', 'name');
    
        });

        return redirect()->back()->with('Success', 'Column Rename add Successfully!');   
    }
    public function deleteColumn($table_name){

         Schema::table($table_name, function($table)
         {
           $table->dropColumn('sdjdj');
         });
         return redirect()->back()->with('danger', 'Column Deleted Successfully!');   
    }

    public function addNewColumn($table_name)
    {
        Schema::table($table_name, function (Blueprint $table) {
            $table->string('sdjdj')->nullable();
        });

        return redirect()->back()->with('Success', 'New Column Deleted Successfully!');   
    }

    public function tableDetail($table_name){

        $columns = DB::getSchemaBuilder()->getColumnListing($table_name);
        $field_data = DB::table($table_name)->get();
    
        return view('tables.table-detail', ['columns'=>$columns, 'field_data'=>$field_data, 'table_name'=>$table_name]);
    }

    public function changeField($table_name){

        Schema::table($table_name, function (Blueprint $table){

        $table->string('name', 50)->nullable()->change();
    });
    
     }

    public function getInputType(request $request)
  {
   
    $states = DB::table("input_type_table")
                ->where("data_type_id", $request->data_type_id)
                ->pluck("input_type_name","id");
                // dd($states);
    return response()->json($states);
  }

}
