<!DOCTYPE html>
<html>
  <head>
  
    <title>Title of the document</title>
  </head>
  <body>
    <h1>PDF Example with iframe</h1>
   @foreach($filename as $file)
   
    <iframe src="{{$file}}" width="100%" height="900"></iframe>
   @endforeach
  </body>
</html>