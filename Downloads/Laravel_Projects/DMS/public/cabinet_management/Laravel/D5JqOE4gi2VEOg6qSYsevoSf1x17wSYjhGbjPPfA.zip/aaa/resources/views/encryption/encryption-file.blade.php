<!DOCTYPE html>
<html lang="en">
<head>
  <title>Encryption File</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container mt-3">
  <form action="{{url('/encryption-file')}}" method="POST" enctype="multipart/form-data">
  @csrf
    <p>Custom file:</p>
    <div class="custom-file mb-3">
      <input type="file" class="custom-file-input" id="customFile" name="filename">
      <label class="custom-file-label" for="customFile">Choose file</label>
    </div>
    
    <!-- <p>Default file:</p>
    <input type="file" id="myFile" name="source"> -->
  
     <div class="mt-3">
      <button type="submit" class="btn btn-primary">Submit</button>
    </div>
    <br>
    <div class="row">
    <div class="col-md-12">
    @foreach($files as $file)
    <div>{{$file}}</div>
      <button type="btn" class="btn btn-success"> <a href="{{url('/files')}}/{{basename($file)}}" style="color:white;">
                Download
            </a></button>
            <button type="btn" class="btn btn-info"><a href="{{url('/view-pdf-file')}}" style="color:white;"> View Pdf File</a></button>
    @endforeach
    </div>
    </div>
  </form>
</div>

<script>
// Add the following code if you want the name of the file appear on select
$(".custom-file-input").on("change", function() {
  var fileName = $(this).val().split("\\").pop();
  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
});
</script>

</body>
</html>
