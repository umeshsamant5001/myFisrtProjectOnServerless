<?php

namespace App\Http\Controllers;

use App\Folder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;

class FolderController extends Controller
{
    public function formSubmit(Request $request)
    {
        $user = auth()->user();
        
        // dd($user->name);
        $path = public_path($user->name);
       
        if(!File::isDirectory($path)){
            File::makeDirectory($path, 0777, true, true);

            if(File::isDirectory($path)){

             File::makeDirectory($path.'/'.$user->name, 0777, true, true);

            return redirect()->back()->with('alert', 'User Name Folder Created Successfully');
            }
        }else{

            return redirect()->back()->with('alert', 'User Name Folder already exit! ');  
        }
       
    }
}