@extends('layouts.app')

@section('content')
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  

    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<div class="card uper">
<div class="card-header">
  <h4 style="text-align:center;">Details Of Tables</h4>
  <b><a class="btn btn-info" href="{{url('/table-index')}}"><span class="glyphicon glyphicon-circle-arrow-left"></span> Back</a></b>
  <b><a class="btn btn-info active" href="{{url('show')}}/{{$table_name}}"><span class="glyphicon glyphicon-plus-sign"></span> Brower</a></b>
  <b><a class="btn btn-info" href="{{ url('/structure') }}/{{$table_name}}"><span class="glyphicon glyphicon-plus-sign"></span> Structure</a></b> 
  <b><a class="btn btn-info" href="{{ url('table-record-insert') }}/{{$table_name}}"><span class="glyphicon glyphicon-plus-sign"></span> Insert</a></b>
   </div>
 
  <div class="card-body">
    @if(session()->get('success'))
    <div class="alert alert-success">
      {{ session()->get('success') }}  
    </div><br/>
    @endif
     <table class="table table-striped">
    <thead style="background-color:skyblue;">
    <tr>
    <td>Action</td>
    @foreach($columns as $table)
    <td>{{$table}}</td>
    @endforeach
    </tr>
    </thead>
    <tbody>
    @foreach($field_data as $key=>$value)
    <tr style="display:block-inline;">
    <td>
    <!-- <a href="{{url('table-record-edit')}}/{{$table_name}}/{{$value->id}}"><span class="glyphicon glyphicon-pencil" style="color:orange;"></span> Edit </a> -->
    <!-- <a href="{{url('table-record-copy')}}"> <span class="glyphicon glyphicon-copy"></span>Copy</a> -->
    <a href="{{ url('table-record-delete')}}/{{$table_name}}/{{$value->id}}"><span class="glyphicon glyphicon-minus-sign" style="color:red;"></span>Delete</a></td>
    @foreach($columns as $table)
    <td>{{$value->$table}}</td>
    @endforeach  
    </tr>
    @endforeach
    </tbody>
  </table>
  </div>
</div>
</body>
</html>
@endsection