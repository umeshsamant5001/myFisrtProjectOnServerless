<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableInfosTable extends Migration
{
   
    public function up()
    {
        Schema::create('table_infos', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('table_name');
            $table->string('column_name');
            $table->string('control_type');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('table_infos');
    }
}
