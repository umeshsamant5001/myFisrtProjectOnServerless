<?php

namespace App\Http\Controllers;

use App\table_info;
use Illuminate\Http\Request;
use DB;

class TableInfoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function storeDataTable(Request $request)
    {
        $data = new table_info();
        $data->table_name = $request->table_name;
        $data->column_name = $request->name;
        $data->control_type = $request->control_type;
        $data->save();

        $links = implode(' ',$data);
        dd($links);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\table_info  $table_info
     * @return \Illuminate\Http\Response
     */
    public function show(table_info $table_info)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\table_info  $table_info
     * @return \Illuminate\Http\Response
     */
    public function edit(table_info $table_info)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\table_info  $table_info
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, table_info $table_info)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\table_info  $table_info
     * @return \Illuminate\Http\Response
     */
    public function destroy(table_info $table_info)
    {
        //
    }
}
