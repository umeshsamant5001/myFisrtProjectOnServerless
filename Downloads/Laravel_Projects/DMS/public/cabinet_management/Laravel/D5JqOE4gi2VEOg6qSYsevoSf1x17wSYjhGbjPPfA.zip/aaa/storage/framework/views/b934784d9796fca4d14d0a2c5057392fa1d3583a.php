<!DOCTYPE html>
<html>
  <head>
    <title>Title of the document</title>
  </head>
  <body>
    <h1>PDF Example with iframe</h1>
   <?php $__currentLoopData = $filename; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <iframe src="<?php echo e($file); ?>" width="100%" height="900"></iframe>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </body>
</html><?php /**PATH C:\xampp\htdocs\DMS\resources\views/encryption/view-pdf-file.blade.php ENDPATH**/ ?>