<?php $__env->startSection('content'); ?>
<!DOCTYPE html>

<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  

    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

</head>
<body>
 
  <div class="card uper">
<div class="card-header"> 
  <h4 style="text-align:center;">Details Of Tables</h4>
  <b><a class="btn btn-info" href="<?php echo e(url('/table-index')); ?>"><span class="glyphicon glyphicon-circle-arrow-left"></span> Back</a></b>
  <b><a class="btn btn-info active" href="<?php echo e(url('show')); ?>/<?php echo e($table_name); ?>"><span class="glyphicon glyphicon-plus-sign"></span> Brower</a></b>
  <b><a class="btn btn-info" href="<?php echo e(url('structure')); ?>/<?php echo e($table_name); ?>"><span class="glyphicon glyphicon-plus-sign"></span> Structure</a></b> 
  <b><a class="btn btn-info" href="<?php echo e(url('table-record-insert')); ?>/<?php echo e($table_name); ?>"><span class="glyphicon glyphicon-plus-sign"></span> Insert</a></b>
   </div>
 
  <div class="card-body">
    <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br/>
    <?php endif; ?>
     <table class="table table-striped">
    <thead style="background-color:skyblue;">
     <tr>
     <th>Name</th>
     <th></th>
     <th>Type</th>
     <th></th>
     <th>Null</th>
     <th></th>
     <th>Key</th>
     <th></th>
     <th>Default</th>
     <th></th>
     <th>Extra</th>
     <th></th>
     <th>Action</th>
   </tr>
   </thead>
    <tbody>
    <tr>

<?php for($i =0; $i < count($datatype); $i++): ?>

<?php $__currentLoopData = $datatype[$i]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<td><?php echo e($value); ?><td>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<td>
<a href="<?php echo e(url('/column-add')); ?>/<?php echo e($table_name); ?>"><span class="glyphicon glyphicon-plus-sign" style="color:green;"></span>Add Column</a>
<a href="<?php echo e(url('/column-rename')); ?>/<?php echo e($table_name); ?>"><span class="glyphicon glyphicon-pencil" style="color:orange;"></span>Change</a>
<a href="<?php echo e(url('/column-drop')); ?>/<?php echo e($table_name); ?>"><span class="glyphicon glyphicon-minus-sign" style="color:red;"></span>Drop</a></td>
 </tr>
 <?php endfor; ?>
    </tbody>
  </table>
  </div>
</div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DMS\resources\views/tables/table-structure.blade.php ENDPATH**/ ?>