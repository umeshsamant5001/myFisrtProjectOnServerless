<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Contracts\Encryption\DecryptException;

$encrypted = Crypt::encryptString('Hello world.');

$decrypted = Crypt::decryptString($encrypted);

class UserController extends Controller
{
    //
    public function storeSecret(Request $request){
    $data = "path: It is a mandatory parameter which specifies the path. mode : It is an optional parameter which specifies permission.
    The mode parameter consists of four numbers: The first number is always zero. The second number specifies permissions for the owner.
    The third number specifies permissions for the owner’s user group. The fourth number specifies permissions for everybody else.
    The set of possible values are :
    1 = execute permissions
    2 = write permissions
    4 = read permission. Multiple permissions can be set by adding up the following numbers. recursive: It is an optional parameter which can be used to set recursive mode.
    context : It is an optional parameter which specifies the behavior of the stream.";
        $user = encrypt($data);

        $decrypt = decrypt($user);
        // $user = User::findOrFail('6');

        // $user->fill([
        //     'secret' => encrypt($request->secret)
        // ])->save();
        // dd($user);
        dd($user);


        $encrypted = Crypt::encryptString('Hello World.');

        $decrypted = Crypt::decryptString($encrypted);

        dd($encrypted);

        // try {

        //  $decrypted = decrypt($encryptedValue);
            
        // } catch (DecryptException $e){

        // }

    }
}
