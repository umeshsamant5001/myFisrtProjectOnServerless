<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>

  <div class="card uper">

  <div class="card-header">
    <a class="btn btn-primary" href="<?php echo e(route('companys.create')); ?>"> Create New Company</a>
  </div>
 
  <div class="card-body">
    <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br />
  <?php endif; ?>
     <table class="table table-striped">
    <thead>
        <tr style="background-color:skyblue;">
          <td>Sr. No</td>
          <td>Company Name</td>
          <td>Company Location</td>
          <td colspan="3">Action</td>
        </tr>
    </thead>
    <tbody>
    <?php if(count($companys)>0): ?>
        <?php $__currentLoopData = $companys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->index+1); ?></td>
            <td><?php echo e($comp->name); ?></td>
            <td><?php echo e($comp->location); ?></td>
            <td><a href="<?php echo e(route('companys.edit',$comp->id)); ?>" class="btn btn-primary">Edit</a></td>
            <td><a class="btn btn-primary" href="<?php echo e(route('companys.show',$comp->id)); ?>">Show</a></td>
            <td>
                <form action="<?php echo e(route('companys.destroy', $comp->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-danger" type="submit">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <h3>Database is Empty!!</h3> 
        <?php endif; ?>
    </tbody>
  </table>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DMS\resources\views/companys/company-index.blade.php ENDPATH**/ ?>