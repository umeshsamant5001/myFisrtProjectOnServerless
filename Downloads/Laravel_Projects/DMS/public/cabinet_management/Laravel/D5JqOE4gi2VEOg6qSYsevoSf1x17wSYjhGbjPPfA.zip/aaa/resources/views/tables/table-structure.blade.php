@extends('layouts.app')

@section('content')
<!DOCTYPE html>

<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  

    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

</head>
<body>
 
  <div class="card uper">
<div class="card-header"> 
  <h4 style="text-align:center;">Details Of Tables</h4>
  <b><a class="btn btn-info" href="{{url('/table-index')}}"><span class="glyphicon glyphicon-circle-arrow-left"></span> Back</a></b>
  <b><a class="btn btn-info active" href="{{url('show')}}/{{$table_name}}"><span class="glyphicon glyphicon-plus-sign"></span> Brower</a></b>
  <b><a class="btn btn-info" href="{{ url('structure') }}/{{$table_name}}"><span class="glyphicon glyphicon-plus-sign"></span> Structure</a></b> 
  <b><a class="btn btn-info" href="{{ url('table-record-insert') }}/{{$table_name}}"><span class="glyphicon glyphicon-plus-sign"></span> Insert</a></b>
   </div>
 
  <div class="card-body">
    @if(session()->get('success'))
    <div class="alert alert-success">
      {{ session()->get('success') }}  
    </div><br/>
    @endif
     <table class="table table-striped">
    <thead style="background-color:skyblue;">
     <tr>
     <th>Name</th>
     <th></th>
     <th>Type</th>
     <th></th>
     <th>Null</th>
     <th></th>
     <th>Key</th>
     <th></th>
     <th>Default</th>
     <th></th>
     <th>Extra</th>
     <th></th>
     <th>Action</th>
   </tr>
   </thead>
    <tbody>
    <tr>

@for($i =0; $i < count($datatype); $i++)

@foreach($datatype[$i] as $key=>$value)

<td>{{$value}}<td>
@endforeach

<td>
<a href="{{url('/column-add')}}/{{$table_name}}"><span class="glyphicon glyphicon-plus-sign" style="color:green;"></span>Add Column</a>
<a href="{{url('/column-rename')}}/{{$table_name}}"><span class="glyphicon glyphicon-pencil" style="color:orange;"></span>Change</a>
<a href="{{url('/column-drop')}}/{{$table_name}}"><span class="glyphicon glyphicon-minus-sign" style="color:red;"></span>Drop</a></td>
 </tr>
 @endfor
    </tbody>
  </table>
  </div>
</div>
</body>
</html>
@endsection