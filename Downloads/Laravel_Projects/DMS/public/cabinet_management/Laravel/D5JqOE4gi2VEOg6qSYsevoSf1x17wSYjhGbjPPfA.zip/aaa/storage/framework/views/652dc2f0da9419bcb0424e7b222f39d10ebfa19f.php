<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">
    Edit company
  </div>
  <div class="card-body">
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
      <form method="post" action="<?php echo e(route('companys.update', $company->id)); ?>">
        <?php echo csrf_field(); ?>

        <?php echo method_field('PUT'); ?>

        <div class="form-group">
          <label for="name">Name:</label>
          <input type="text" class="form-control" name="name" id="company_title" value="<?php echo e($company->name); ?>" />
        </div>
        <div class="form-group">
          <label for="location">Location:</label>
          <input name="location" value="<?php echo e($company->location); ?>" id="company_body" class="form-control">
        </div>
        
        <button type="submit" class="btn btn-primary">Update</button>
      </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DMS\resources\views/companys/company-edit.blade.php ENDPATH**/ ?>