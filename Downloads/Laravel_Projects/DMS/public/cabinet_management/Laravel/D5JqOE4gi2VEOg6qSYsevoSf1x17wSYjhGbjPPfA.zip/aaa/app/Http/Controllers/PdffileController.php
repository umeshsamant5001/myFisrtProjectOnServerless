<?php

namespace App\Http\Controllers;

use App\Pdffile;
use Illuminate\Http\Request;

class PdffileController extends Controller
{
    public function file(){
        return view('');
    }
    
    public function getDownload($filename){
        if($filename){
                $file=  base_path().'/public/uploads/documents/'.$filename;
              if (file_exists($file)){
                  return response()->download($file);
              }else{
               exit('Requested file does not exist on our server!');
               //redirect to the other page to display not found
               // message if you want
              }

         }else{
           exit('URL not found exception');
         }
     
  }
  public function view($id)
  {
     $document_name = "";

       if($document_name){
                $file =  base_path().'/public/uploads/documents/'.$document_name;
              if (file_exists($file)){

                 $ext =File::extension($file);
                
                  if($ext=='pdf'){
                      $content_types='application/pdf';
                     }elseif ($ext=='doc') {
                       $content_types='application/msword';  
                     }elseif ($ext=='docx') {
                       $content_types='application/vnd.openxmlformats-officedocument.wordprocessingml.document';  
                     }elseif ($ext=='xls') {
                       $content_types='application/vnd.ms-excel';  
                     }elseif ($ext=='xlsx') {
                       $content_types='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';  
                     }elseif ($ext=='txt') {
                       $content_types='application/octet-stream';  
                     }
                 
                  return response(file_get_contents($file),200)
                         ->header('Content-Type',$content_types);
                                                           
              }else{
               exit('Requested file does not exist on our server!');
              }

         }else{
           exit('Invalid Request');
         } 
  }
}
