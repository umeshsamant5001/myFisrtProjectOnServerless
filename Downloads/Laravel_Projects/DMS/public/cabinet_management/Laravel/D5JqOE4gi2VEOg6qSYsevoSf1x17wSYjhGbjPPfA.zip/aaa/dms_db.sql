-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2020 at 01:26 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `name`, `location`, `contact`, `created_at`, `updated_at`) VALUES
(5, 'Amdocs', 'Baner, Pune', 565677, NULL, NULL),
(12, 'Accenture', 'Hinjewadi phage 3', 565677, NULL, NULL),
(13, 'Wipro', 'Magarpatta, Pune', 565677, NULL, NULL),
(19, 'Sonali', 'Pune Magarpatta', 88821782, NULL, NULL),
(24, 'Anjalee', 'Baner, Pune', 565677, NULL, NULL),
(29, 'Nexa Software', 'Hinjewadi phage 3', 565677, '2020-01-15 09:51:13', '2020-01-15 09:51:13'),
(30, 'Wiproggh', 'Hinjewadi phage 3', 54656, '2020-01-16 04:38:21', '2020-01-16 04:38:21'),
(31, 'dsds', 'sdsdfdsf', 22234434, '2020-01-16 04:38:35', '2020-01-16 04:38:35');

-- --------------------------------------------------------

--
-- Table structure for table `encryptions`
--

CREATE TABLE `encryptions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `file`
--

CREATE TABLE `file` (
  `id` int(10) UNSIGNED NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `makar_sankranti`
--

CREATE TABLE `makar_sankranti` (
  `id` int(10) UNSIGNED NOT NULL,
  `cane_sugar` blob NOT NULL,
  `bore` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `edahala` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tandul` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `dusa` blob NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `makar_sankranti`
--

INSERT INTO `makar_sankranti` (`id`, `cane_sugar`, `bore`, `edahala`, `tandul`, `dusa`, `created_at`, `updated_at`) VALUES
(2, 0x646473, 'dfdfg', 'xccssd', 'ssdf', 0x7361646166, NULL, NULL),
(3, 0x63616e652073756761722069732068657265, 'bore is here', 'dahala is here', 'Tadul is van', 0x6475736120616c736f2069732076616e, NULL, NULL),
(4, 0x63616e65207375676172206973206865726520666f722063656c656272617465207468652066756e6374696f6e, 'bore is here for celebrate the function', 'dahala sugar is here for celebrate the function', 'tandul  is here for celebrate the function', 0x64757361206973206865726520666f722063656c656272617465207468652066756e6374696f6e, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2020_01_02_100330_create_companies_table', 2),
(5, '2014_10_12_000000_create_sonali_table', 3),
(6, '2020_01_10_072841_create_folders_table', 4),
(7, '2020_01_11_121433_create_table_records_table', 5),
(8, '2020_01_16_061325_create_encryptions_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `table_records`
--

CREATE TABLE `table_records` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'DMS', 'dms2020@gmail.com', NULL, '$2y$10$Co4SKi6rnKQoIMJ5jZZsZeR2GnfeuZYti4c.j6Dh83HN2QuFoPzHO', 'dqdD3EryVM5tKmUPdZ6DZopEqLe6k3Zchngw2eKtiKtV63wr4ilXFZ63S4Mg', '2020-01-02 01:19:39', '2020-01-02 01:19:39'),
(2, 'Sonali', 'sonali@gmail.com', NULL, '$2y$10$rAQpJGR2gWC2mDeY.R2S8.qJ1ZNKNK06wHBMNQrRMwgKYRieIxj12', 'FQkt1eb5XHa45UHefK3LEqkJpEzE2KHHpgNo4QexeWnVd8QRE0pBO0E3cdlb', '2020-01-02 03:11:10', '2020-01-02 03:11:10'),
(4, 'Sumit', 'sumit15@gmail.com', NULL, '$2y$10$L0bkazmuCIqRpdQjtAeShuJSeOEKAohGvdNTweWqHZG0jOPFSQzY2', NULL, '2020-01-02 04:09:25', '2020-01-02 04:09:25'),
(5, 'Sumit', 'sumit151@gmail.com', NULL, '$2y$10$oFtMJAJu/GzrYFqWHqMfMeZoSVebGNqmorfzPA9Uc36bCPm22ySGm', NULL, '2020-01-02 04:10:04', '2020-01-02 04:10:04'),
(6, 'Namrata', 'namrata111@gmail.com', NULL, '$2y$10$m9p5Six3CDwt.zLrHUT7aOWwM9vQujbfe/NjWiGY6ZHSh50.w2r4W', NULL, '2020-01-02 04:12:34', '2020-01-02 04:12:34'),
(7, 'Sumit', 'sumit@gmail.com', NULL, '$2y$10$kqI42DieV6Kg3jjOmB3WHeKfZzwWip9y/r8km4CyUpRYaJBtj2Gom', NULL, '2020-01-17 05:29:13', '2020-01-17 05:29:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `encryptions`
--
ALTER TABLE `encryptions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `file`
--
ALTER TABLE `file`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `makar_sankranti`
--
ALTER TABLE `makar_sankranti`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `table_records`
--
ALTER TABLE `table_records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `encryptions`
--
ALTER TABLE `encryptions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `file`
--
ALTER TABLE `file`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `makar_sankranti`
--
ALTER TABLE `makar_sankranti`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `table_records`
--
ALTER TABLE `table_records`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
