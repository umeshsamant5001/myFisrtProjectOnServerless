<?php

namespace App\Http\Controllers;

use App\form;
use Illuminate\Http\Request;
use DB;

class FormController extends Controller
{
    public function index(){
        return view('forms.form-create');
    }
}
