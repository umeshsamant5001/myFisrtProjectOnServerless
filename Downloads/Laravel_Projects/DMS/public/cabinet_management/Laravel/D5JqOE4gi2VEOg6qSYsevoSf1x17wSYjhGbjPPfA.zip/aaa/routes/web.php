<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index');

// Route::get('company-index', 'CompanyController@index');
// Route::get('company-create', 'CompanyController@create');
// Route::post('company-store', 'CompanyController@store');
// Route::get('company-edit/id', 'CompanyController@edit');
// Route::post('company-update/id', 'CompanyController@update');
// Route::get('company-delete', 'CompanyController@destroy');

// company
Route::resource('companys', 'CompanyController');

// Table Create
Route::get('/table-index', 'TableController@index');
Route::get('/table-create', 'TableController@showTable');
Route::post('/table-store', 'TableController@operate');
Route::get('/table-delete/{Tables_in_dms_db}', 'TableController@down');
Route::get('/show/{Tables_in_dms_db}', 'TableController@tableDetail');

Route::get('/table-rename/{Tables_in_dms_db}', 'TableController@renameTable');
Route::get('/encrypt', 'UserController@storeSecret');

Route::get('/add-column', function(){
    return view('tables.add-column');
});

//Column name update & delete
Route::get('/column-rename/{Tables_in_dms_db}', 'TableController@renameColumn');
Route::get('/column-drop/{Tables_in_dms_db}', 'TableController@deleteColumn');
Route::get('/column-add/{Tables_in_dms_db}', 'TableController@addNewColumn');

// Data Insert
Route::get('/table-record-insert/{Tables_in_dms_db}', 'TableRecordController@createDynamicForm');
Route::post('/table-record-store/{Tables_in_dms_db}', 'TableRecordController@storeDynamicForm');
Route::get('/table-record-edit/{Tables_in_dms_db}/{id}', 'TableRecordController@editRecord');
// Route::get('/table-record-copy', 'TableRecordController@copyRecord');
Route::get('/table-record-delete/{Tables_in_dms_db}/{id}', 'TableRecordController@deleteRecord');
Route::get('/structure/{Tables_in_dms_db}', 'TableRecordController@tableStructure');

// Encryption File
Route::get('/encryption', 'EncryptionController@index');
Route::post('/encryption-file', 'EncryptionController@encryptFile');
Route::get('/files/{filename}', 'EncryptionController@downloadFile');

// pdf in iframe
Route::post('/upload-pdf-file', 'EncryptionController@uploadPdfFile');
Route::get('/view-pdf-file', 'EncryptionController@viewPdfFile');

// folder creation
Route::get('folder-create', 'FolderController@formSubmit');

// pdf view
Route::get('/pdf-view-downloads/{filename}', 'PdffileController@getDownload');

// input type selection for form
Route::get('get-input-type', 'TableController@getInputType');

// dynamic form creation
Route::get('/form-creation', 'FormController@index');