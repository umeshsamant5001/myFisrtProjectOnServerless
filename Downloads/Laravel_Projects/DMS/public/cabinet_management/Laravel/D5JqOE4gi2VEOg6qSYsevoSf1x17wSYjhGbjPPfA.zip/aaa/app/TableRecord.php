<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TableRecord extends Model
{
    //
}
