@extends('layouts.app')
@section('content')
<!DOCTYPE html>
<head>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
 
 <div class="card uper">
<div class="card-header">
  <h4 style="text-align:center;">Details Of Tables</h4>
  <b><a class="btn btn-info" href="{{url('/table-index')}}"><span class="glyphicon glyphicon-circle-arrow-left"></span> Back</a></b>
  <b><a class="btn btn-info active" href="{{url('show')}}/{{$table_name}}"><span class="glyphicon glyphicon-plus-sign"></span> Brower</a></b>
  <b><a class="btn btn-info" href="{{ url('/structure') }}/{{$table_name}}"><span class="glyphicon glyphicon-plus-sign"></span> Structure</a></b> 
  <b><a class="btn btn-info" href="{{ url('table-record-insert') }}/{{$table_name}}"><span class="glyphicon glyphicon-plus-sign"></span> Insert</a></b>
</div>
 
  <div class="card-body">
    @if(session()->get('success'))
    <div class="alert alert-success">
      {{ session()->get('success') }}  
    </div><br/>
    @endif
    <form method="POST" action="" data-type="">
    @csrf
     <table class="table table-striped">
    <thead style="background-color:skyblue;">
     <tr>
     <th>Column</th>
     <th>Type</th>
     <th>Null</th>
     <th>Value</th>
     <!-- <th>Key</th>
     <th></th>
     <th>Default</th>
     <th></th>
     <th>Extra</th> -->
   </tr>
   </thead>
    <tbody>
 
 @foreach($datatype as $value)
 <tr>
 <td>{{$value->Field}}</td>
 <td>{{$value->Type}}</td>
 @if($value->Type == 'timestamp')
 <td><input type="checkbox" value="2" name="{{$value->Field}}"></td>
 @else 
 <td></td>
 @endif

 @foreach($data_edit[0] as $edit)
 @endforeach
 <td><input type="{{$value->Type}}" class="form-control" value="{{$edit}}" name="{{$value->Field}}"><td>
 </tr>
 @endforeach
  </tbody>
 </table>
 <input type="submit" class="btn btn-primary" style="float:right;" value="Go">
 </form>
</div>
</div>
</body>
</html>
@endsection