@extends('layouts.app')

@section('content')
<!DOCTYPE html>
<head>
<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>

<body>
 
  <div class="card uper">
<div class="card-header">
  <h4 style="text-align:center;">Details Of Tables</h4>
  <b><a class="btn btn-info" href="{{url('/table-index')}}"><span class="glyphicon glyphicon-circle-arrow-left"></span> Back</a></b>
  <b><a class="btn btn-info active" href="{{url('show')}}/{{$table_name}}"><span class="glyphicon glyphicon-plus-sign"></span> Brower</a></b>
  <b><a class="btn btn-info" href="{{ url('/structure') }}/{{$table_name}}"><span class="glyphicon glyphicon-plus-sign"></span> Structure</a></b> 
  <b><a class="btn btn-info" href="{{ url('table-record-insert') }}/{{$table_name}}"><span class="glyphicon glyphicon-plus-sign"></span> Insert</a></b>
   </div>
 
  <div class="card-body">
    @if(session()->get('success'))
    <div class="alert alert-success">
      {{ session()->get('success') }}  
    </div><br/>
    @endif
    <form method="POST" action="{{url('/table-record-store')}}/{{$table_name}}" data-type="">
    @csrf
    <h3>Form</h3>
    @foreach($table_info as $label)
    <div class="form-group row">  
   <label for="example-text-input" class="col-2 col-form-label">{{$label['display_name']}}</label>
   <div class="col-10">
   @if($label['control_type'] == 'select')
    <select class="form-control" type="text" name="{{$label['column_name']}}" value="Artisanal kale" id="example-text-input">
    <option>Select Name</option>
    <option>Sonali</option>
    <option>Nisha</option>
    <option>Nikita</option>
    </select>
    @elseif ($label['control_type'] == 'textarea')
    <textarea rows="9" class="form-control" type="text" name="{{$label['column_name']}}" value="Artisanal kale" id="example-text-input"></textarea>
    @elseif ($label['control_type'] == 'textbox')
    <input class="form-control" type="text" name="{{$label['column_name']}}" id="example-text-input"></textarea>
    @elseif ($label['control_type'] == 'checkbox')
    <input  class="form-control" type="checkbox" name="{{$label['column_name']}}" id="example-text-input"></input>
    @else
    <input class="form-control" type="text" name="{{$label['column_name']}}" value="Artisanal kale" id="example-text-input">
    @endif
  </div>
</div>
@endforeach
<input type="submit" class="btn btn-success" style="margin-left:260px;" value="Save" class="form-control">
</form>
@endsection