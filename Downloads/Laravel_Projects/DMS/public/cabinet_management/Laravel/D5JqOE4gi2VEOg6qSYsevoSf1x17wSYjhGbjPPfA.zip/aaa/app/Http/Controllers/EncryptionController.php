<?php

namespace App\Http\Controllers;

use App\Encryption;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Storage;
use SoareCostin\FileVault\Facades\FileVault;
use SoareCostin\FileVault\FileVaultServiceProvider;

class EncryptionController extends Controller
{
  public function index() {

    $files = Storage::files('public/sonali');
    return view('encryption.encryption-file', ['files'=>$files]);
  }

 public function encryptFile(request $request)
   {
    if ($request->hasFile('filename') && $request->file('filename')->isValid()) {

      $filename = Storage::putFile('public/sonali',$request->file('filename'));
      // Check to see if we have a valid file uploaded
      if ($filename) {
          FileVault::encrypt($filename);
      }
  }
  return redirect()->back()->with('message', 'Upload complete');
  }
  
  public function downloadFile($filename)
  {   
     // Basic validation to check if the file exists and is in the user directory
     if (!Storage::has('public/sonali/'. $filename)) {
      abort(404);
  }

  return response()->streamDownload(function () use ($filename) {
      FileVault::streamDecrypt('public/sonali/'. $filename);
  }, Str::replaceLast('.enc', '', $filename));
  }

  public function viewPdfFile() 
  {
    $filename = Storage::files('public/sonali');

     foreach( $filename as $file){
      
       $dd = Str::replaceLast('.enc', '', $file);
      
       $ff = FileVault::streamDecrypt($dd);
      dd($ff);
   }
    return view('encryption.view-pdf-file', ['filename'=>$filename]);
  } 
}
