@extends('layouts.app')

@section('content')
<style>
  .uper {
    margin-top: 40px;
  }
</style>

  <div class="card uper">

  <div class="card-header">
    <a class="btn btn-primary" href="{{ route('companys.create') }}"> Create New Company</a>
  </div>
 
  <div class="card-body">
    @if(session()->get('success'))
    <div class="alert alert-success">
      {{ session()->get('success') }}  
    </div><br />
  @endif
     <table class="table table-striped">
    <thead>
        <tr style="background-color:skyblue;">
          <td>Sr. No</td>
          <td>Company Name</td>
          <td>Company Location</td>
          <td colspan="3">Action</td>
        </tr>
    </thead>
    <tbody>
    @if(count($companys)>0)
        @foreach($companys as $comp)
        <tr>
            <td>{{$loop->index+1}}</td>
            <td>{{$comp->name}}</td>
            <td>{{$comp->location}}</td>
            <td><a href="{{ route('companys.edit',$comp->id)}}" class="btn btn-primary">Edit</a></td>
            <td><a class="btn btn-primary" href="{{ route('companys.show',$comp->id) }}">Show</a></td>
            <td>
                <form action="{{ route('companys.destroy', $comp->id)}}" method="post">
                  @csrf
                  @method('DELETE')
                  <button class="btn btn-danger" type="submit">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
        @else
        <h3>Database is Empty!!</h3> 
        @endif
    </tbody>
  </table>
  </div>
</div>

@endsection