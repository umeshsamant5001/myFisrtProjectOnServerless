<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<head>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>

<body>
 
  <div class="card uper">
<div class="card-header">
  <h4 style="text-align:center;">Details Of Tables</h4>
  <b><a class="btn btn-info" href="<?php echo e(url('/table-index')); ?>"><span class="glyphicon glyphicon-circle-arrow-left"></span> Back</a></b>
  <b><a class="btn btn-info active" href="<?php echo e(url('show')); ?>/<?php echo e($table_name); ?>"><span class="glyphicon glyphicon-plus-sign"></span> Brower</a></b>
  <b><a class="btn btn-info" href="<?php echo e(url('/structure')); ?>/<?php echo e($table_name); ?>"><span class="glyphicon glyphicon-plus-sign"></span> Structure</a></b> 
  <b><a class="btn btn-info" href="<?php echo e(url('table-record-insert')); ?>/<?php echo e($table_name); ?>"><span class="glyphicon glyphicon-plus-sign"></span> Insert</a></b>
   </div>
 
  <div class="card-body">
    <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br/>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(url('/table-record-store')); ?>/<?php echo e($table_name); ?>" data-type="">
    <?php echo csrf_field(); ?>
    <h3>Form</h3>
    <?php $__currentLoopData = $table_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group row">  
   <label for="example-text-input" class="col-2 col-form-label"><?php echo e($label['display_name']); ?></label>
   <div class="col-10">
   <?php if($label['control_type'] == 'select'): ?>
    <select class="form-control" type="text" name="<?php echo e($label['column_name']); ?>" value="Artisanal kale" id="example-text-input">
    <option>Select Name</option>
    <option>Sonali</option>
    <option>Nisha</option>
    <option>Nikita</option>
    </select>
    <?php elseif($label['control_type'] == 'textarea'): ?>
    <textarea rows="9" class="form-control" type="text" name="<?php echo e($label['column_name']); ?>" value="Artisanal kale" id="example-text-input"></textarea>
    <?php elseif($label['control_type'] == 'textbox'): ?>
    <input class="form-control" type="text" name="<?php echo e($label['column_name']); ?>" id="example-text-input"></textarea>
    <?php elseif($label['control_type'] == 'checkbox'): ?>
    <input  class="form-control" type="checkbox" name="<?php echo e($label['column_name']); ?>" id="example-text-input"></input>
    <?php else: ?>
    <input class="form-control" type="text" name="<?php echo e($label['column_name']); ?>" value="Artisanal kale" id="example-text-input">
    <?php endif; ?>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<input type="submit" class="btn btn-success" style="margin-left:260px;" value="Save" class="form-control">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\DMS\resources\views/tables/table-insert-form.blade.php ENDPATH**/ ?>