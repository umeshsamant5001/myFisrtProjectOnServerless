<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class table_info extends Model
{
    protected $table = 'table_infos';
}
