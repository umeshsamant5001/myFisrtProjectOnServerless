<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>
<title>Dynamically Add Table In Database</title>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
</head>

<body>
<div class="container">
<div class="row">
<div class="col-sm-8" style="border:1px solid black;padding:6px;"> 
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br />
    <?php endif; ?>
  <h4 style="text-align:center;">Create New Table In Database</h4>  

    <div class="form-group">

         <form name="add_name" method="POST" action="<?php echo e(url('/table-store')); ?>">
          <?php echo csrf_field(); ?>
            <div class="table-responsive">  
          
                <table class="table table-bordered" id="dynamic_field">  
                  <tr>   
                    <th>Table Name</th>  
                    <td colspan="6"><input type="text" name="table_name" class="form-control" required=""></td>
                  </tr>

                  <tr style="background-color:skyblue;">    
                     <th>Name</th>  
                     <th>Type</th>
                     <th>Length/Values</th>
                     <th>Control</th>
                     <th colspan="2">Display Name</th>
                  </tr>  
                    <tr> 
                        <td><input type="text" name="name[]"class="form-control name_list" required=""/></td>  
                        <td style="display:none;"><select required="" id="datype" name="type[]" class="form-control">
                        <?php $__currentLoopData = $data_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($data->data_type_name); ?>"><?php echo e($data->data_type_name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
                        </td>
                        <td><select id="select2" name="dtype" class="form-control">
                        <?php $__currentLoopData = $data_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($key); ?>"><?php echo e($value->data_type_name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
                       </td>
                        <td><input type="text" required="" name="size[]" class="form-control"/></td>
                        <td><select name="control_type" id="control_type"  class="form-control"></select></td>
                        <td><input type="text" name="display_name[]" class="form-control"><td>
                        <button type="button" name="add" id="add" class="btn btn-success">Add</button> 
                    </tr>  
                  </table>  
                <input type="submit" name="submit" id="submit" class="btn btn-info" value="Save"/>  
            </div>
        </form>
    </div> 
</div>

<div class="col-sm-4" style="border:1px solid black;padding:0px;"> 

  <div class="card uper">

  <div class="card-header">
  <h4 style="text-align:center;">List Of Tables</h4> 
  </div>
 
  <div class="card-body">
    <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br />
    <?php endif; ?>
     <table class="table table-striped">
    <thead>
        <tr style="background-color:skyblue;">
          <td>Sr. No</td>
          <td>Table Name</td>
          <td colspan="3">Action</td>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $table_na; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->index+1); ?></td>
            <td><a href="<?php echo e(url('show')); ?>/<?php echo e($table->Tables_in_promagnh_dms_db); ?>"><?php echo e($table->Tables_in_promagnh_dms_db); ?></a></td>
            <td><a class="btn btn-danger" href="<?php echo e(url('table-delete')); ?>/<?php echo e($table->Tables_in_promagnh_dms_db); ?>">Drop</a></td>
            <!-- <td><a class="btn btn-primary" href="<?php echo e(url('table-rename')); ?>/<?php echo e($table->Tables_in_promagnh_dms_db); ?>">Rename</a></td> -->
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  </div>
</div>
</div>
</div>
</body>
</html>
<script>
// if (document.addEventListener) {
//         document.addEventListener('contextmenu', function(e) {
//              //here you draw your own menu
//             e.preventDefault();
//         }, false);
//     } else {
//         document.attachEvent('oncontextmenu', function() {
//            window.event.returnValue = false;
//         });
//     }
</script>
<script type="text/javascript">

    $(document).ready(function(){      

      var i=1;  

      $('#add').click(function(){  

           i++;  

           $('#dynamic_field').append('<tr id="row'+i+'" class="dynamic-added"><td><input type="text" name="name[]"class="form-control name_list" required=""/></td><td style="display:none;"><select required="" id="datype" name="type[]" class="form-control"><?php $__currentLoopData = $data_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($data->data_type_name); ?>"><?php echo e($data->data_type_name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></td><td><select id="select2" name="dtype" class="form-control"><?php $__currentLoopData = $data_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($key); ?>"><?php echo e($value->data_type_name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></td><td><input type="text" required="" name="size[]" class="form-control"/></td><td><select name="control_type" id="control_type"  class="form-control"></select></td><td><input type="text" name="display_name[]" class="form-control"><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></tr>');  

      });

      $(document).on('click', '.btn_remove', function(){  

           var button_id = $(this).attr("id");   

           $('#row'+button_id+'').remove();  

      });  

    });  

</script>
<script>
  $('#select2').change(function(){
    var countryID = $(this).val(); 
    
    if(countryID){
     $.ajax({
          url:"<?php echo e(url('get-input-type')); ?>?data_type_id="+countryID,
           type:"get",
           data: 'json',
           success:function(data){              
            if(data){ 
                $("#control_type").empty();
                $("#control_type").append('<option>select</option>');
                $.each(data,function(key,value){
                    $("#control_type").append('<option value="'+value+'">'+value+'</option>');
                });
           
            }else{
               $("#control_type").empty();
            }
           }
        });
    }
   });
</script>

<script>
var $selects = $('#datype, #select2').on('change', function(){
   $selects.not(this).prop('selectedIndex', this.selectedIndex)
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/promagnh/public_html/dms/resources/views/tables/table-index.blade.php ENDPATH**/ ?>